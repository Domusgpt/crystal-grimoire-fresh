import React, { useState, useCallback } from 'react';
import { analyzeImage } from '../services/geminiService';
import { ImagePart, AnalysisResponse } from '../types';
import { Spinner } from './Spinner';

const MAX_IMAGE_DIMENSION = 512;

const DataField: React.FC<{ label: string; value: React.ReactNode }> = ({ label, value }) => (
  <div className="border-t border-gray-700 pt-2 mt-2">
    <dt className="font-medium text-gray-400 text-xs">{label}</dt>
    <dd className="mt-1 text-sm text-gray-200">{value}</dd>
  </div>
);

export const ImageAnalyzer: React.FC = () => {
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [analysisResult, setAnalysisResult] = useState<AnalysisResponse | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleImageChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setImageFile(file);
      const newImageUrl = URL.createObjectURL(file);
      setImageUrl(newImageUrl);
      // Reset state for new image
      setAnalysisResult(null);
      setError(null);
    }
  };

  const processImageAndAnalyze = useCallback(async () => {
    if (!imageFile) {
      setError("Please upload an image to analyze.");
      return;
    }

    setIsLoading(true);
    setError(null);
    setAnalysisResult(null);

    const image = new Image();
    image.src = URL.createObjectURL(imageFile);
    image.onload = async () => {
      try {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        if (!ctx) throw new Error("Could not get canvas context");

        // Downsize image for efficiency
        const scale = MAX_IMAGE_DIMENSION / Math.max(image.width, image.height);
        const width = image.width * scale;
        const height = image.height * scale;
        canvas.width = width;
        canvas.height = height;
        ctx.drawImage(image, 0, 0, width, height);
        
        const dataUrl = canvas.toDataURL('image/jpeg', 0.9);
        const base64Data = dataUrl.split(',')[1];
        
        const imagePart: ImagePart = {
          inlineData: {
            mimeType: 'image/jpeg',
            data: base64Data
          }
        };
        
        const result = await analyzeImage(imagePart);
        setAnalysisResult(result);
      } catch (e) {
        console.error(e);
        setError(e instanceof Error ? e.message : 'An unexpected error occurred during image processing.');
      } finally {
        setIsLoading(false);
      }
    };
    image.onerror = () => {
        setError("Failed to load the image for processing.");
        setIsLoading(false);
    }
  }, [imageFile]);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
      {/* Left Column: Controls & Image */}
      <div className="flex flex-col gap-6 p-6 bg-gray-800/50 rounded-lg border border-gray-700">
        <div>
          <label htmlFor="file-upload" className="block text-sm font-medium text-gray-300 mb-2">1. Upload Image</label>
          <input
            id="file-upload"
            type="file"
            accept="image/*"
            onChange={handleImageChange}
            className="block w-full text-sm text-gray-400 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-cyan-600 file:text-white hover:file:bg-cyan-700 cursor-pointer"
          />
        </div>

        {imageUrl && (
          <>
            <div className="flex-grow aspect-square relative bg-gray-900 rounded-md overflow-hidden border border-gray-600">
              <img src={imageUrl} alt="Analysis subject" className="absolute inset-0 w-full h-full object-contain" />
            </div>
            
            <div className="text-xs text-gray-400 bg-gray-900/50 p-3 rounded-md border border-gray-700">
              <h4 className="font-bold text-gray-300">Analysis Method</h4>
              <p>For the most accurate identification, we analyze the entire image. To keep the analysis fast and cost-effective, your image is automatically downsized before being sent to our AI gemologist.</p>
            </div>
          </>
        )}
      </div>

      {/* Right Column: Analysis & Results */}
      <div className="flex flex-col gap-4 p-6 bg-gray-800/50 rounded-lg border border-gray-700">
          <h2 className="text-xl font-semibold text-white">2. Analyze & Review</h2>
          <button
            onClick={processImageAndAnalyze}
            disabled={isLoading || !imageFile}
            className="w-full flex justify-center items-center gap-2 bg-cyan-600 hover:bg-cyan-700 disabled:bg-gray-600 disabled:cursor-not-allowed text-white font-bold py-3 px-4 rounded-md transition-colors text-lg"
          >
            {isLoading ? <><Spinner /> Analyzing...</> : "Ask AI Gemologist"}
          </button>
        
        {error && <div className="bg-red-900/50 border border-red-700 text-red-300 px-4 py-3 rounded-md text-sm">{error}</div>}

        <div className="flex-grow bg-gray-900/70 p-4 rounded-md border border-gray-700 min-h-[200px] prose prose-invert prose-sm max-w-none text-gray-300">
          <h3 className="text-lg font-medium text-gray-200 mb-2">AI Gemologist Report</h3>
          {isLoading && !analysisResult && (
             <div className="text-gray-400 animate-pulse">Waiting for analysis from Gemini...</div>
          )}
          {analysisResult ? (
            <div className="whitespace-pre-wrap">{analysisResult.report}</div>
          ) : (
            !isLoading && <div className="text-gray-500">Your detailed crystal analysis will appear here.</div>
          )}
        </div>
        
        {analysisResult && (
          <div className="space-y-4">
            <div className="bg-gray-900/70 p-4 rounded-md border border-gray-700">
              <h3 className="text-lg font-medium text-gray-200 mb-2">Metaphysical & Geological Data</h3>
              <dl className="space-y-2">
                <DataField label="Crystal Type" value={analysisResult.data.crystal_type} />
                <DataField label="Colors" value={analysisResult.data.colors.join(', ')} />
                <DataField label="Primary Chakras" value={analysisResult.data.metaphysical_properties.primary_chakras.join(', ')} />
                <DataField label="Element" value={analysisResult.data.metaphysical_properties.element} />
                <DataField label="Zodiac Signs" value={analysisResult.data.metaphysical_properties.zodiac_signs.join(', ')} />
                <DataField label="Healing Properties" value={analysisResult.data.metaphysical_properties.healing_properties.join(', ')} />
                <DataField label="Mohs Hardness" value={analysisResult.data.geological_data.mohs_hardness} />
                <DataField label="Chemical Formula" value={<code>{analysisResult.data.geological_data.chemical_formula}</code>} />
                <DataField label="Analysis Date" value={analysisResult.data.analysis_date} />
              </dl>
            </div>
             <div className="bg-gray-900/70 p-4 rounded-md border border-gray-700">
              <h3 className="text-lg font-medium text-gray-200 mb-2">Raw JSON Output</h3>
              <pre className="text-xs bg-black/50 p-3 rounded-md overflow-x-auto text-cyan-300">
                <code>{JSON.stringify(analysisResult.data, null, 2)}</code>
              </pre>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
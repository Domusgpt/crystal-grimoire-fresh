import { GoogleGenAI, Type } from "@google/genai";
import { ImagePart, AnalysisResponse } from '../types';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

const responseSchema = {
  type: Type.OBJECT,
  properties: {
    report: {
      type: Type.STRING,
      description: "A detailed report in markdown format. The focus should be on the crystal's metaphysical and spiritual properties, while also including basic geological information. The tone should be mystical and informative.",
    },
    data: {
      type: Type.OBJECT,
      properties: {
        crystal_type: { type: Type.STRING, description: "The most likely name of the crystal or mineral." },
        colors: {
          type: Type.ARRAY,
          items: { type: Type.STRING },
          description: "An array of dominant colors observed in the image.",
        },
        analysis_date: {
          type: Type.STRING,
          description: "The current date of the analysis in ISO 8601 format (YYYY-MM-DD).",
        },
        metaphysical_properties: {
          type: Type.OBJECT,
          properties: {
            primary_chakras: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Associated primary chakras (e.g., 'Root', 'Sacral', 'Heart')." },
            element: { type: Type.STRING, description: "Associated element (e.g., 'Earth', 'Water', 'Fire', 'Air')." },
            zodiac_signs: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Associated zodiac signs (e.g., 'Aries', 'Taurus')." },
            healing_properties: { type: Type.ARRAY, items: { type: Type.STRING }, description: "A list of key spiritual and healing properties." },
          },
          required: ['primary_chakras', 'element', 'zodiac_signs', 'healing_properties']
        },
        geological_data: {
          type: Type.OBJECT,
          properties: {
            mohs_hardness: { type: Type.STRING, description: "The Mohs hardness scale rating (e.g., '7', '4-5')." },
            chemical_formula: { type: Type.STRING, description: "The chemical formula (e.g., 'SiO2')." },
          },
          required: ['mohs_hardness', 'chemical_formula']
        }
      },
      required: ['crystal_type', 'colors', 'analysis_date', 'metaphysical_properties', 'geological_data']
    }
  },
  required: ['report', 'data']
};

export const analyzeImage = async (imagePart: ImagePart): Promise<AnalysisResponse> => {
  try {
    const textPart = {
      text: `You are a world-class gemologist and spiritual guide. Analyze the provided image to identify any crystals, minerals, or stones. Your response must be a JSON object that strictly adheres to the provided schema.
      
      In the 'report' field, write a detailed analysis in markdown format. Start the report by clearly stating the official mineral name for clarity (e.g., "**Identified Mineral: Quartz (Amethyst variety)**"). Then, the primary focus should be on the metaphysical and spiritual information. Include the standard geological details but weave them into a more mystical narrative.
      
      In the 'data' field, populate the structured information accurately based on your identification. For 'analysis_date', use today's date.
      
      If no crystals are apparent, the 'crystal_type' should be 'Unknown' and the report should explain what is seen instead.`,
    };

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-pro',
      contents: { parts: [textPart, imagePart] },
      config: {
        responseMimeType: 'application/json',
        responseSchema: responseSchema,
        systemInstruction: 'You are an expert gemologist providing detailed mineral identification and metaphysical properties in a structured JSON format.'
      }
    });

    const jsonText = response.text.trim();
    return JSON.parse(jsonText) as AnalysisResponse;

  } catch (error) {
    console.error("Error analyzing image with Gemini:", error);
    if (error instanceof Error) {
        throw new Error(`An error occurred during analysis: ${error.message}`);
    }
    throw new Error("An unknown error occurred during analysis.");
  }
};
export interface ImagePart {
  inlineData: {
    mimeType: string;
    data: string;
  };
}

export interface AnalysisResponse {
  report: string; // The detailed metaphysical report in markdown
  data: {
    crystal_type: string;
    colors: string[];
    analysis_date: string;
    metaphysical_properties: {
      primary_chakras: string[];
      element: string;
      zodiac_signs: string[];
      healing_properties: string[];
    };
    geological_data: {
      mohs_hardness: string;
      chemical_formula: string;
    };
  };
}

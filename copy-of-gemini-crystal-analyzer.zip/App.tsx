
import React from 'react';
import { ImageAnalyzer } from './components/ImageAnalyzer';

const App: React.FC = () => {
  return (
    <div className="min-h-screen bg-gray-900 text-gray-100 font-sans">
      <header className="bg-gray-800/50 backdrop-blur-sm border-b border-gray-700 sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4 flex items-center">
           <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-cyan-400 mr-3" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M11.3 1.046A1 1 0 0112 2v1.046l4.243 4.242a1 1 0 01-.707 1.707L13 8.336v2.328l2.5 2.5a1 1 0 01-1.414 1.414L12 12.414v2.539a1 1 0 01-1.707.707L6.05 13.414a1 1 0 010-1.414L10 8.05V5.512L7.05 2.562a1 1 0 011.414-1.414L11 3.586V2a1 1 0 01.3-.707zM6.05 11.999a1 1 0 011.414 0L10 14.536V17a1 1 0 01-2 0v-2.046l-4.243-4.242a1 1 0 01.707-1.707L8 9.664v-2.328L5.5 4.836a1 1 0 011.414-1.414L9.164 5.672 6.05 8.786a1 1 0 010 1.414l.001 8.799z" clipRule="evenodd" />
          </svg>
          <h1 className="text-2xl font-bold text-white tracking-tight">
            Gemini Crystal Analyzer
          </h1>
        </div>
      </header>
      <main className="container mx-auto px-4 py-8">
        <ImageAnalyzer />
      </main>
      <footer className="text-center py-4 text-gray-500 text-sm">
        <p>Powered by Gemini. Built for token efficiency.</p>
      </footer>
    </div>
  );
};

export default App;
